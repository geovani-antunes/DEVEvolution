SELECT REPLACE(name, 'H1', 'X') AS name
FROM virus;