SELECT name, street
FROM customers
WHERE city = 'Porto Alegre';
