<?php
interface FormaGeometrica {
    public function calcularArea();
    public function calcularPerimetro();

    
}
