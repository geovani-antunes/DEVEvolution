<?php
require_once "Pessoa_01.php";

$p1 = new Pessoa_01("Geovani",18,"Masculino");


print_r($p1);
?>

